// Copyright Epic Games, Inc. All Rights Reserved.

#include "PixelStreamingStreamerVideoInput.h"

UPixelStreamingStreamerVideoInput::UPixelStreamingStreamerVideoInput(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}
