// Copyright Epic Games, Inc. All Rights Reserved.

#include "PixelStreamingServersLog.h"

DEFINE_LOG_CATEGORY(LogPixelStreamingServers);