// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

enum class PIXELSTREAMINGHMD_API EPixelStreamingXRSystem : uint8
{
	Unknown,
	HTCVive,
	Quest,
};