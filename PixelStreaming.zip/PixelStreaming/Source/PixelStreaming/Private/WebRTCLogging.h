// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "rtc_base/logging.h"

void RedirectWebRtcLogsToUnreal(rtc::LoggingSeverity Verbosity);
