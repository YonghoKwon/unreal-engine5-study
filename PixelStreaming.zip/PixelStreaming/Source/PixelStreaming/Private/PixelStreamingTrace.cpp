// Copyright Epic Games, Inc. All Rights Reserved.

#include "PixelStreamingTrace.h"

#include "Trace/Trace.inl"

UE_TRACE_CHANNEL_DEFINE(PixelStreamingChannel);
