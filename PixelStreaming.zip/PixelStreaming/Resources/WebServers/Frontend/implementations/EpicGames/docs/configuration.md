# Configuration of the Frontend UI

Todo
