The images directory
