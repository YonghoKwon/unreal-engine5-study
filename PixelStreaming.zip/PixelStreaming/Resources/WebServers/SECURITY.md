# Security Policy

## Supported Versions

These versions are currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 5.2     | :white_check_mark: |
| 5.1     | :white_check_mark: |
| 5.0     | :white_check_mark: |
| 4.27    | :white_check_mark: |

## Reporting a Vulnerability

If you find a vulnerability please open and advisory here: https://github.com/EpicGames/PixelStreamingInfrastructure/security/advisories/new
