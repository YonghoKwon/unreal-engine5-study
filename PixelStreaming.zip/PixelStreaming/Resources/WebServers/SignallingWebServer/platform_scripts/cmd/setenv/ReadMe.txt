
SetEnv
Version 1.09 - ( For Windows 9x/NT/2000/XP/S2K3/Vista )

Copyright (C) 2005-2008 - Jonathan Wilkes - All Rights Reserved.
http://www.xanya.net

================================================================================

1. Installation

	Simply download and run the Setup_SetEnv.exe application to install SetEnv.

2. Using SetEnv

	The SetEnv is a free tool for setting/updating/deleting System Environment Variables.
	Type the following at a command prompt (assumes SetEnv.exe is in current path), for command line usage information.

		setenv -?

	See our website for full usage details, http://www.xanya.net/site/utils/setenv.php

3. Version History

	1.09 [Fix] - (Feb 9, 2008) - Fixed a problem on Windows 98 where it sometimes failed to open the Autoexec.bat file.
	1.08 [New] - (May 31, 2007) - Added how to delete a USER environment variable to the usage information.
	1.07 [Fix] - (Jan 25, 2007) - Fixed a bug found by depaolim.
	1.06 [New] - (Jan 14, 2007) - Added dynamic expansion support (same as using ~ with setx)
		- Originally requested by Andre Amaral, further Request by Synetech
	1.05 [New] - (Sep 06, 2006) - Added support to prepend (rather than append) a value to an expanded string 
		- Requested by Masuia
	1.04 [New] - (May 30, 2006) - Added support for User environment variables.
	1.03 [Fix] - (Apr 20, 2006) - Bug fix in ProcessWinXP() discovered by attiasr 
	1.01 [Fix] - (Nov 15, 2005) - Bug fix in IsWinME() discovered by frankd 
	1.00 [New] - (Oct 29, 2005) - Initial Public Release.

4. License and Terms of Use

	Please see the License.txt file for licensing information.

5. Reporting Problems

	If you encounter any problems whilst using SetEnv, please try downloading the latest version from http://www.xanya.net to see if the problem has already been resolved.
	If this does not help, then please send an e-mail to darka@xanya.net with details describing the problem.

================================================================================